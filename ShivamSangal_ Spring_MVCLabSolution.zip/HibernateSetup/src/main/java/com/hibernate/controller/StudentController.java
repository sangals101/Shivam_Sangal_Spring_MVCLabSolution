package com.hibernate.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hibernate.poc.model.Student;
import com.hibernate.poc.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	private StudentService studentService;

	@RequestMapping("/home")
	public String listBooks(Map<String, Object> map) {
		map.put("student", new Student());
		map.put("studentList", studentService.getAllStudents());
		return "student";
	}

	@RequestMapping(value = "/student/add", method = RequestMethod.POST)
	public String addStudent(@ModelAttribute("student") Student student, BindingResult result) {
		if (null != student) {
			studentService.addStudent(student);
		}
		return "redirect:/home";
	}

	@RequestMapping("/delete/{studentId}")
	public String deleteStudent(@PathVariable("studentId") int studentId) {
		studentService.deleteStudent(studentId);
		return "redirect:/home";
	}

	@RequestMapping("/edit/{studentId}")
	public String editStudent(@PathVariable("studentId") int studentId, Map<String, Object> map) {
		Student student = studentService.getStudentById(studentId);
		// Providing new value for Edit
		student.setStudentName("EditedName");
		studentService.updateStudent(student);
		map.put("studentList", studentService.getAllStudents());
		return "redirect:/home";
	}

	public StudentService getStudentService() {
		return studentService;
	}

	public void setUserService(StudentService studentService) {
		this.studentService = studentService;
	}

}
