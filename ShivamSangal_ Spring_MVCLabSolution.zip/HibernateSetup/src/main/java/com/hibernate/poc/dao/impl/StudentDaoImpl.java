package com.hibernate.poc.dao.impl;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hibernate.poc.model.studentDao;
import com.hibernate.poc.model.Student;

@Repository
public class StudentDaoImpl implements studentDao {

	@Autowired
	private SessionFactory sessionFactory;

	// Create of CRUD
	public void addUser(Student student) {
		sessionFactory.getCurrentSession().save(student);
	}

	// Read of CRUD
	@SuppressWarnings("unchecked")
	public List<Student> getAllStudents() {
		return sessionFactory.getCurrentSession().createQuery("from User").getResultList();
	}

	// Read of CRUD
	public Student getUserById(int studentid) {

		Session session = sessionFactory.getCurrentSession();
		Student student = null;
		String hqlQuery = "from User where id = :id";
		@SuppressWarnings("rawtypes")
		Query query = session.createQuery(hqlQuery);
		query.setParameter("studentId", studentid);
		student = (Student) query.getSingleResult();
		return student;
	}

	// Update of CRUD
	public void updateStudent(Student student) {
		sessionFactory.getCurrentSession().update(student);
	}

	// Delete of CRUD
	public void deleteStudent(int studentid) {

		Student student = (Student) sessionFactory.getCurrentSession().load(Student.class, studentid);
		if (null != student) {
			sessionFactory.getCurrentSession().delete(student);
		}

	}

	@Override
	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Student getStudentById(int studentid) {
		// TODO Auto-generated method stub
		return null;
	}



}
