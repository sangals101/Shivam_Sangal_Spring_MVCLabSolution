package com.hibernate.poc.model;

import java.util.List;

import com.hibernate.poc.model.Student;

public interface studentDao {

		 public void addStudent(Student student);
		 
		 public List<Student> getAllStudents();
		 
		 public Student getStudentById(int studentid);
		 
		 public void updateStudent(Student student);
		 
		 public void deleteStudent(int studentid);

	
}
