package com.hibernate.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hibernate.poc.model.Student;
import com.hibernate.poc.service.StudentService;
import com.hibernate.poc.model.studentDao;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private studentDao studentDao;

	// Create of CRUD
	@Transactional
	public void addStudent(Student student) {
		studentDao.addStudent(student);
	}

	// Read of CRUD
	@Transactional
	public List<Student> getAllStudents() {
		return studentDao.getAllStudents();
	}

	// Read of CRUD
	@Transactional
	public Student getUserById(int studentid) {
		return studentDao.getStudentById(studentid);
	}

	// Update of CRUD
	@Transactional
	public void updateUser(Student student) {
		studentDao.updateStudent(student);
	}

	// Delete of CRUD
	@Transactional
	public void deleteStudent(int studentid) {
		studentDao.deleteStudent(studentid);
	}

	public studentDao getStudentDao() {
		return studentDao;
	}

	public void setStudentDao(studentDao studentDao) {
		this.studentDao = studentDao;
	}

	@Override
	public Student getStudentById(int studentid) {
		// TODO Auto-generated method stub
		return studentDao.getStudentById(studentid);
	}

	@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		
	}
}
